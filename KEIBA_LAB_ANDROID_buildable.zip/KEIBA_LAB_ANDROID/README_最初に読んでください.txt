KEIBA LAB Androidプロジェクト（APK自動ビルド対応）

このZIPはAndroidアプリのソース一式です。APKそのものではありません。
GitHub ActionsでAPKを自動生成する設定を追加しました。

APKを作る方法（PCなしでもGitHubのブラウザ操作で進められます）：
1. GitHubにログインし、新しい空のリポジトリを作成
2. このZIPを展開し、中のファイル・フォルダをリポジトリ直下へアップロード
   ※ ZIPファイルそのものをリポジトリに置くだけでは動きません。
3. mainブランチへ反映すると、自動でAPKビルドが始まります。
4. GitHubリポジトリの Actions を開き、成功した「Build KEIBA LAB APK」を選択
5. Artifacts欄の「KEIBA-LAB-debug-apk」をダウンロードし、ZIPを展開
6. 中の app-debug.apk をAndroid端末で開いてインストール
   Android側で初回のみ「不明なアプリのインストール」を許可する必要があります。

手動で再ビルドする場合：Actions > Build KEIBA LAB APK > Run workflow

Android Studioで直接ビルドする場合：
- Android Studioでこのフォルダを開く
- Android SDK Platform 35を導入
- Gradle 8.9 / Android Gradle Plugin 8.7.3で :app:assembleDebug を実行

アプリの現状と制約：
- 既存のKEIBA LAB LOCAL HTMLをWebViewで表示するAndroidラッパー
- UTF-8、JavaScript、DOMストレージ、CSVファイル選択に対応
- 出馬表・オッズの自動取得サーバーは未実装
- 予想ロジックの的中率・回収率は未検証。利益や的中を保証しません
- debug APKはテスト用署名です。一般配布用の正式署名版ではありません
- 実機での最終動作確認はまだです
